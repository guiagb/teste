package br.com.ecommerce.implementacao;
import br.com.ecommerce.beans.Cliente;
import br.com.ecommerce.beans.ClientePF;
import br.com.ecommerce.beans.ClientePJ;
import br.com.ecommerce.beans.Endereco;
import br.com.ecommerce.beans.Venda;
import br.com.ecommerce.util.Magica;

public class ImplementarCliente2 {

	public static void main(String[] args) {

		char resp = Magica.s("digite <f> para fisica ou <j> para juridica").charAt(0);
		Cliente objeto = new Cliente();
		if(resp=='F') {
			objeto = new ClientePF("gui","22222",
					new Endereco("rua x", "70", "casa", "bela vista", "osasco", "sp", "06070050"),
					"666","555");
			System.out.println(objeto.toString());
		}else if (resp=='J') {
			objeto = new ClientePJ("guipj", "123", 
					new Endereco("rua x", "70", "casa", "bela vista", "osasco", "sp", "06070050"), 
					"666", "555");
			System.out.println(objeto.toString());
		}else {
			System.out.println("op��o invalida");
		}
		
		System.out.println(objeto.getBasico());
		System.out.println(objeto.toString());
		
		
		Venda venda = new Venda();
		venda.setCliente(objeto);
		System.out.println(venda.getCliente().identificarCliente());
		
	
		
	}

}
